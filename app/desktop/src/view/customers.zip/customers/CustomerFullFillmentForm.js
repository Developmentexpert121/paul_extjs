Ext.define('JanviewPro.view.customers.CustomerFullFillmentForm', {
    extend: 'Ext.form.Panel',
     xtype: 'customerFullFillmentForm',
     requires: ['JanviewPro.view.customers.CustomerFullFillmentFormViewController'],
     controller: {
         xclass: 'JanviewPro.view.customers.CustomerFullFillmentFormViewController'
    },
    cls: 'customerView',
    model: 'JanviewPro.model.UnitFranchiseModel',
    title: 'UF Contract Fullfillment',
    bodyPadding: 10,
    width: '100%',
    defaultType: 'textfield',
    xtype:'form',
    formId:'customerFullFillmentForm',
    itemId:'formid',
    layout: {
        type: 'hbox',
        align: 'middle'
    },
    fieldDefaults:
                    {
                        labelAlign: 'top',
                        labelStyle: 'font-weight:bold'
                    },
    items: [
        {
            xtype: 'combobox',
            label: 'Franchisee Name',
            name: 'franchiseeName',
            displayField: 'value',
            typeAhead: true,
            required: true,
            width: '100%',
            store: {
            fields: ['value'],
            data: [
            { value: ''},
            { value: 'Name1'},
            { value: 'Name2'},
    
        ],
            listeners: {
            change: 'onCalculatedFieldChange'
        }
    }
    },
     {

             width: '50%',
             xtype: 'label',
             flex: 1,
             border: false,
             height: '',
             name: 'customerName',
             style: 'font-size: 21px;text-align: center;margin: auto;flex: 1 1 0%;background-color: #157fcc;color: #fff;font: 600 18px/24px Roboto; sans-serif;min-height: 27px;margin: 10px 10px 10px 10px',

             html: 'Loan Payment',
             labelAlign : 'top'
            
         },    
    {
        xtype: 'combobox',
        label: 'Customer Name (this is the account the loan payment will be deducted from)',
        name: 'customerName',
        displayField: 'value',
        typeAhead: true,
        required: true,
        width: '100%',
        store: {
        fields: ['value'],
        data: [
        { value: ''},
        { value: 'Customer1'},
        { value: 'Customer2'},

    ],
        listeners: {
        change: 'onCalculatedFieldChange'
    }
}
    }, 
    {
        xtype: 'datefield',
        label: 'Start Date',
        name: 'startDate',
        allowBlank: false,
       // placeholder: 'Select Start Date',
        width: '50%',
    },
    {
        xtype: 'numberfield',
        label: 'Monthly Loan Payment Amount',
        name: 'monthlyLoanPaymentAmount',
        allowBlank: false,
        width: '50%',
    },
     {
        xtype: 'numberfield',
        label: 'Number of months to pay off the loan',
        name: 'numberOfMonths',
        allowBlank: false,
        required: true,
        width: '50%',
    }, 
    {
        xtype: 'filefield',
        label: 'Choose fullfilment letter',
        name: 'fullfilmentLetter',
        allowBlank: false,
        store: ['Letter A', 'Letter B', 'Letter C'],
        queryMode: 'local',
        emptyText: 'Select a letter',
        required: true,
        width: '50%',
    },
        {
            xtype: 'button',
            text: 'Save',
            handler: 'onSaveClick'
        },
        {
            xtype: 'button',
            text: 'Cancel',
            handler: 'onCancelClick'
        },
    ],
 });

 
